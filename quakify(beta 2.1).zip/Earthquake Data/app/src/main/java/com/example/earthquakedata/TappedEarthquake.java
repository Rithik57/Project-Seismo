package com.example.earthquakedata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOError;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.Buffer;
import java.nio.channels.InterruptedByTimeoutException;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.SimpleTimeZone;

import static android.provider.ContactsContract.CommonDataKinds.Website.URL;

public class TappedEarthquake extends AppCompatActivity {

    //creating a log tag
    private static final String LOG_TAG = TappedEarthquake.class.getName();
    String EVENT_REQUEST_URL = "https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&eventtype=earthquake&eventid=";
    private String mapURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tapped_earthquake);
        //receive the eventId from main and set up a connection to parse the id using JSON
        String eventid = getIntent().getStringExtra("EVENTID");
        Log.e(LOG_TAG,"the event id was received by the new activity");
        EVENT_REQUEST_URL = "https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&eventtype=earthquake&eventid="+eventid;
        getQuakeInfo runner = new getQuakeInfo();
        runner.execute(EVENT_REQUEST_URL);
    }

    private class getQuakeInfo extends AsyncTask<String, Integer ,quakes>{

        @Override
        protected quakes doInBackground(String... strings) {
            try{
                URL queryURL = new URL(strings[0]);
                //getting the json response from the server
                String jsonResponse = makeHttpRequest(queryURL);
                Log.e(LOG_TAG,"the jsonresponse was acquired by the background thread");
                //storing the json info in a quakes object
                try{
                    quakes Earthquake = getJsonInfo(jsonResponse); //the JSON info is stored in this object
                    return Earthquake;
                }catch (JSONException e){
                    Log.e(LOG_TAG,"there was a problem parsing the data from the JSON response");
                }
            }catch (MalformedURLException e){
                Log.e(LOG_TAG,"there was a problem converting the string into URL");
            } catch (IOException e) {
                Log.e(LOG_TAG,"there was an IOException from the makeHttpRequest method");
            }
            return null;
        }

        @Override
        protected void onPostExecute(quakes currentQuake) { //this method receives the object from the background thread and updates the UI
            Log.e(LOG_TAG,"the postExecute method was called");
            updateUI(currentQuake);
        }
    }

    //## this method returns a quake object that has the data given by the json page
    public quakes getJsonInfo(String jsonResponse) throws JSONException{
        quakes object = new quakes();
        JSONObject baseJSON = new JSONObject(jsonResponse);
        JSONObject properties = baseJSON.getJSONObject("properties");
        String location = properties.getString("place");
        double magnitude = properties.getDouble("mag");
        String alert = properties.getString("alert");
        String time = properties.getString("time");
        int tsunamiStatus = properties.getInt("tsunami"); //tsunami status is 0 for false and 1 for true
        String url = properties.getString("url");
        Log.e(LOG_TAG,"location was : "+location+" mag was : "+magnitude+" alert level : "+alert+" time was : "+time+" tsunami status"+tsunamiStatus+" url : "+url);
        //storing the info in a quakes object
        object.setLocation(location);
        object.setMag(magnitude);
        object.setAlertLevel(alert);
        object.setTime(time);
        object.setTsunamiStatus(tsunamiStatus);
        object.setUrl(url);
        return object;
    }

    //## this method returns the JSON response corresponding to the request URL given to it
    public static String makeHttpRequest(URL url) throws IOException {
        String JSON_RESPONSE = ""; //placeholder for json response
        HttpURLConnection urlConnection = null; //creating a connection variables
        InputStream inputStream = null; //input stream for reading from the response
        Log.e(LOG_TAG,"the makeHttpRequest method was run");
        try{
            urlConnection = (HttpURLConnection)url.openConnection();
            urlConnection.setReadTimeout(10000);
            urlConnection.setConnectTimeout(15000);
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();
            if(urlConnection.getResponseCode() == 200){
                inputStream = urlConnection.getInputStream();
                JSON_RESPONSE = readFromStream(inputStream);
            }
        }catch( IOException e){
            Log.e(LOG_TAG,"error in the makeHTTP request method response code from the server is : "+urlConnection.getResponseCode());
        }finally {
            if(urlConnection !=null){
                urlConnection.disconnect();
            }
            if(inputStream !=null){
                inputStream.close();
            }
        }
        return JSON_RESPONSE;
    }

    //## this method reads the inputStream provided to it
    private static String readFromStream(InputStream inputStream) throws IOException{
        StringBuilder output = new StringBuilder();
        if(inputStream != null){
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String line = bufferedReader.readLine();
            while(line != null){
                output.append(line);
                line = bufferedReader.readLine();
            }
        }
        Log.e(LOG_TAG,"the read from stream method was run");
        return output.toString();
    }

    //## this method updates the UI using the object data received in postExecute method
    public void updateUI(quakes object){
        Log.e(LOG_TAG,"the updateUI method was called in the tappedEarthquake class");
        //setting the place in the title
        TextView locationText = (TextView)findViewById(R.id.quakeLocation);
        locationText.setText(object.getLocation());
        //setting the magnitude
        TextView magnitudeText = (TextView)findViewById(R.id.magText);
        double mag = object.getMag();
        magnitudeText.setText(String.valueOf(mag));
        //setting the alertLevel
        TextView alertLevel = (TextView)findViewById(R.id.alertText);
        alertLevel.setText(object.getAlertLevel());
        //converting the unix time to a readable format :
        String time = object.getTime();
        long unixTime = Long.parseLong(time);      //converting the time string to unix time
        Date dateObject = new Date(unixTime);       //creating an instance of the Date class and giving it the unix time converts it into a readable format
        SimpleDateFormat dateFormatter = new SimpleDateFormat("dd.MM.yyyy hh:mm:ss a");
        dateFormatter.setTimeZone(SimpleTimeZone.getTimeZone("GMT+5:30"));
        String readableDate = dateFormatter.format(dateObject);
        TextView timeText = (TextView)findViewById(R.id.timeText);
        timeText.setText(readableDate);
        String TsunamiStatus;
        if(object.getTsunamiStatus() == 1){
            TsunamiStatus = "yes";
        }else{
            TsunamiStatus = "no";
        }
        Log.e(LOG_TAG,"the tsunami status was received as : "+object.getTsunamiStatus());
        TextView tsunamiText = (TextView)findViewById(R.id.tsunamiText);
        tsunamiText.setText(TsunamiStatus);
        mapURL = object.getUrl();
    }
    //opens the earthquake in maps
    public void viewInMap(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(mapURL));
        startActivity(intent);
    }
}