package com.example.earthquakedata;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceFragment;
import androidx.preference.PreferenceFragmentCompat;

public class quakeSettings extends AppCompatActivity {
    private final String LOGTAG = "quake Settings";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);
        Log.e(LOGTAG,"the quake settings activity was run");
    }

    public static class SettingsFragment extends PreferenceFragment {
        String LOGTAG = "settings Fragment";

        @Override
        public void onCreate(Bundle savedInstanceState) {
            Log.e(LOGTAG,"the settings fragment was run");
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.settings_main);
        }

        @Override
        public void onPause() {
            super.onPause();
            Intent intent = new Intent(getContext(), MainActivity.class);
            startActivity(intent);
        }

        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {

        }
    }
}